DROP brand kit — Ride Smart. Go Further.

Colours: Midnight Navy #071B3A · Dynamic Orange #FF6B00 · Pure White #FFFFFF · Light Grey #F5F7FA
Fonts: Manrope (headlines, 700/800) · Inter (text, 400-600) — Google Fonts, SIL OFL.
"-dark" and "mono-white" files are white artwork on a transparent background, for use on navy or photos.
Full guidelines: /brand on the DROP website.

DROP is a division of VINK Group (Pty) Ltd, registration number 2018/079316/07.
